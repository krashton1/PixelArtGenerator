Ashton Woollard
101011084

Instructions
	Extract all files from this zip into any folder
	Run the exe file
	
	Place path pins on map
	Press space to start the simulation
	Press right to start panning to the right and to pan faster
	Press left to pan slower


Bugs
	-After travelling a far distance (through 6 or so biomes), parralax layers become 'unsynced'. The scroll speed of each layer was eyeballed to find a good fit, which works fine early but starts to fail later

	
	